package mu.mcb.property.evalution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyEvalutionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
