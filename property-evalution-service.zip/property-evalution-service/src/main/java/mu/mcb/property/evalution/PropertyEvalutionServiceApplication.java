package mu.mcb.property.evalution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PropertyEvalutionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PropertyEvalutionServiceApplication.class, args);
	}
}
