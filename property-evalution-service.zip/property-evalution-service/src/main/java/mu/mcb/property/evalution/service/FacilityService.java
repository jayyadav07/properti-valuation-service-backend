package mu.mcb.property.evalution.service;

import java.util.List;

import mu.mcb.property.evalution.dto.FacilityTypeDto;

public interface FacilityService {

	List<FacilityTypeDto> getFacilityTypes();

}
