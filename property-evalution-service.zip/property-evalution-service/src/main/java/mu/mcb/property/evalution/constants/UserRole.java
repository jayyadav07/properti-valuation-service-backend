package mu.mcb.property.evalution.constants;


public enum UserRole {
    ADMIN, USER, BANK_OFFICER,PROPERTY_EVALUATOR, REVIEWER, AUDITOR
}
